import { createClient } from 'honox/client'

createClient()
