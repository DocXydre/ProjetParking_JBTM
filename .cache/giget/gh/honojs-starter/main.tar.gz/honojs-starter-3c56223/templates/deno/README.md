```
deno task start
```
