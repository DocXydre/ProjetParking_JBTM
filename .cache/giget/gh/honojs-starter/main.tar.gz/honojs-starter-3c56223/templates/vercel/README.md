```
npm install
npm run start
```
