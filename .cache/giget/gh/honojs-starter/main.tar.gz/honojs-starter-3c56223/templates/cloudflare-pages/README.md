```txt
npm install
npm run dev
```

```txt
npm run deploy
```
