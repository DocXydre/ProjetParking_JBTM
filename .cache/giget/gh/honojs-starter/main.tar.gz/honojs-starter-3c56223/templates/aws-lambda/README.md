```
npm install
npm run deploy
```
