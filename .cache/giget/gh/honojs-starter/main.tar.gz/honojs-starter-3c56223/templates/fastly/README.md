```
npm install
npm run dev
```

```
open http://localhost:7676
```

```
npm run deploy
```
